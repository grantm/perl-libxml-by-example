#!/usr/bin/perl

use 5.010;
use strict;
use warnings;

use XML::LibXML;
use Data::Dumper;

my $filename = 'book.xml';

my $dom = XML::LibXML->load_xml(location => $filename);

say '$dom is a ', ref($dom);
say '  $dom->nodeName = ', $dom->nodeName;
say '';

say '$dom->documentElement is a ', ref($dom->documentElement);
say '  $dom->documentElement->nodeName = ', $dom->documentElement->nodeName;
say '';

say '$dom->documentElement->ownerDocument is a ', ref($dom->documentElement->ownerDocument);
say '';

my $book = $dom->documentElement;
say '$book->childNodes is a ', ref($book->childNodes);
say '$book->childNodes->size = ', $book->childNodes->size;
my @children = $book->childNodes;
foreach my $i (0..$#children) {
  say "\$children[$i] is a ", ref($children[$i]), ' name = ', $children[$i]->nodeName;
}
say '';

my $results = $dom->findnodes('//author');
say '$results is a ', ref($results);
$results->foreach(sub {
    my $node = shift;
    say $node->to_literal
});
